document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('productForm');
    const input = document.getElementById('productId');
    const resultBox = document.getElementById('result');

    form.addEventListener('submit', function (e) {
        e.preventDefault();

        const productId = input.value.trim();
        if (!productId) {
            resultBox.innerHTML = "<p>Please enter a valid Product ID.</p>";
            return;
        }

        fetch('backend.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `product_id=${encodeURIComponent(productId)}`
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === "error") {
                resultBox.innerHTML = `<p style="color: red;">${data.message}</p>`;
            } else {
                const info = data.data;
                resultBox.innerHTML = `
                    <h3>Product Details</h3>
                    <p><strong>Product ID:</strong> ${info.product_id}</p>
                    <p><strong>Amount:</strong> ₹${info.amount}</p>
                    <p><strong>Status:</strong> ${info.status}</p>
                    <p><strong>Stock (Sold):</strong> ${info.stock_sold}</p>
                    <p><strong>Stock (Warehouse):</strong> ${info.stock_warehouse}</p>
                    <p><strong>Stock (In-Store):</strong> ${info.stock_instore}</p>
                    <p><strong>Customer ID:</strong> ${info.customer_id || 'N/A'}</p>
                    <p><strong>Timestamp:</strong> ${info.timestamp}</p>
                    <p><strong>Description:</strong> ${info.description || 'N/A'}</p>
                `;
            }
        })
        .catch(error => {
            resultBox.innerHTML = `<p style="color: red;">Error fetching data.</p>`;
            console.error(error);
        });
    });
});
