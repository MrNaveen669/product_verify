<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "prod_auth";

// Connect to MySQL
$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create table if not exists
$sql = "CREATE TABLE IF NOT EXISTS products (
    product_id VARCHAR(50) PRIMARY KEY,
    amount DECIMAL(10,2),
    stock_sold INT,
    stock_warehouse INT,
    stock_instore INT,
    status VARCHAR(20),
    customer_id VARCHAR(50),
    timestamp DATETIME,
    description TEXT
)";
$conn->query($sql);

// File upload handling
if (isset($_FILES['file'])) {
    $filename = $_FILES['file']['tmp_name'];
    $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);

    if ($ext === 'csv') {
        $handle = fopen($filename, 'r');
        $headers = fgetcsv($handle); // Skip header row

        while (($row = fgetcsv($handle)) !== FALSE) {
            list($product_id, $amount, $sold, $warehouse, $instore, $status, $customer_id, $timestamp, $desc) = $row;

            $stmt = $conn->prepare("INSERT INTO products (product_id, amount, stock_sold, stock_warehouse, stock_instore, status, customer_id, timestamp, description)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                    amount = VALUES(amount),
                    stock_sold = VALUES(stock_sold),
                    stock_warehouse = VALUES(stock_warehouse),
                    stock_instore = VALUES(stock_instore),
                    status = VALUES(status),
                    customer_id = VALUES(customer_id),
                    timestamp = VALUES(timestamp),
                    description = VALUES(description)");

            $stmt->bind_param("sdiiiisss", $product_id, $amount, $sold, $warehouse, $instore, $status, $customer_id, $timestamp, $desc);
            $stmt->execute();
        }

        fclose($handle);
        echo "CSV data uploaded successfully.";

    } elseif ($ext === 'json') {
        $data = json_decode(file_get_contents($filename), true);

        foreach ($data as $item) {
            $stmt = $conn->prepare("INSERT INTO products (product_id, amount, stock_sold, stock_warehouse, stock_instore, status, customer_id, timestamp, description)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                    amount = VALUES(amount),
                    stock_sold = VALUES(stock_sold),
                    stock_warehouse = VALUES(stock_warehouse),
                    stock_instore = VALUES(stock_instore),
                    status = VALUES(status),
                    customer_id = VALUES(customer_id),
                    timestamp = VALUES(timestamp),
                    description = VALUES(description)");

            $stmt->bind_param("sdiiiisss", 
                $item['product_id'], 
                $item['amount'], 
                $item['stock_sold'], 
                $item['stock_warehouse'], 
                $item['stock_instore'], 
                $item['status'], 
                $item['customer_id'], 
                $item['timestamp'], 
                $item['description']);

            $stmt->execute();
        }

        echo "JSON data uploaded successfully.";
    } else {
        echo "Unsupported file format. Only CSV or JSON allowed.";
    }

} else {
    echo "No file uploaded.";
}

$conn->close();
?>
