<?php
$host = "localhost";
$user = "root";
$password = ""; // No password
$database = "prod_auth";

// Connect to MySQL
$conn = new mysqli($host, $user, $password);

// Check connection
if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}

// Create DB if it doesn't exist
$conn->query("CREATE DATABASE IF NOT EXISTS $database");
$conn->select_db($database);

// Create table if not exists
$sql = "CREATE TABLE IF NOT EXISTS products (
    product_id VARCHAR(20) PRIMARY KEY,
    amount DECIMAL(10,2),
    stock_sold INT,
    stock_warehouse INT,
    stock_instore INT,
    status VARCHAR(20),
    customer_id VARCHAR(20),
    timestamp DATETIME,
    description TEXT
)";

if ($conn->query($sql) === TRUE) {
    echo "✅ Table created or already exists";
} else {
    echo "❌ Failed to create table: " . $conn->error;
}

$conn->close();
?>
