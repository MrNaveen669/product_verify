<?php
header('Content-Type: application/json');

// MySQL credentials (customize as needed)
$host = 'localhost';
$db = 'prod_auth';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed']);
    exit;
}

// Step 1: Create table if it doesn't exist
$createQuery = "
CREATE TABLE IF NOT EXISTS products (
    product_id VARCHAR(50) PRIMARY KEY,
    amount DECIMAL(10, 2),
    stock_sold INT DEFAULT 0,
    stock_warehouse INT DEFAULT 0,
    stock_instore INT DEFAULT 0,
    status VARCHAR(20),
    customer_id VARCHAR(50) DEFAULT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    description TEXT
) ENGINE=InnoDB;
";

$conn->query($createQuery);

// Step 2: Get product ID
if (!isset($_POST['product_id']) || empty(trim($_POST['product_id']))) {
    echo json_encode(['status' => 'error', 'message' => 'Product ID is required']);
    exit;
}

$product_id = $conn->real_escape_string(trim($_POST['product_id']));

// Step 3: Fetch product details
$query = "SELECT * FROM products WHERE product_id = '$product_id'";
$result = $conn->query($query);

if ($result->num_rows === 0) {
    echo json_encode(['status' => 'error', 'message' => 'No product found with this ID']);
} else {
    $row = $result->fetch_assoc();
    echo json_encode(['status' => 'success', 'data' => $row]);
}

$conn->close();
?>
